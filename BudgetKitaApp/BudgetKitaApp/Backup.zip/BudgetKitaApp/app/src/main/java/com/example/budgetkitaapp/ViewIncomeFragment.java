package com.example.budgetkitaapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class ViewIncomeFragment extends Fragment {

    RecyclerView rv1;
    ArrayList<Income> incomeArrayList;
    IncomeAdapter incomeAdapter;
    private FirebaseAuth mAuth;
    DatabaseReference databaseReference;

    public ViewIncomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_view_income, container, false);
        rv1 = v.findViewById(R.id.recycler1);

        //Firebase authentication to identify user
        mAuth = FirebaseAuth.getInstance();
        //only the login user can see their data information
        databaseReference = FirebaseDatabase.getInstance().getReference("Income").child(mAuth.getCurrentUser().getUid()).child("Income");

        incomeArrayList = new ArrayList<>();
        rv1.setHasFixedSize(true);
        rv1.setLayoutManager(new LinearLayoutManager(getActivity()));
        incomeAdapter = new IncomeAdapter(incomeArrayList, getActivity());
        rv1.setAdapter(incomeAdapter);

        databaseReference.get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                incomeArrayList.clear();

                for(DataSnapshot incomeDatasnap : dataSnapshot.getChildren()){
                    Income income = incomeDatasnap.getValue(Income.class);
                    income.setId(incomeDatasnap.getKey());
                    incomeArrayList.add(income);
                }
                incomeAdapter.notifyDataSetChanged();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // if we do not get any data or any error we are displaying
                // a toast message that we do not get any data
                Toast.makeText(getActivity(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
            }
        });

        return v;
    }
}