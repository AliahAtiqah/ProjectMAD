package com.example.budgetkitaapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {

    private TextView transactionLink, transactionViewLink;
    private CardView addTransactionCard, viewIncomeExpensesCard;
    private ImageView profileLink, logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //Make textview clickable and link it to next Transaction Activity
        transactionLink = (TextView) findViewById(R.id.transactionLinkPage);
        transactionLink.setOnClickListener(view -> {
            Intent send = new Intent(HomeActivity.this, TransactionActivity.class);
            startActivity(send);
        });

        //Make cardview clickable and link it to next Transaction Activity
        addTransactionCard = (CardView) findViewById(R.id.cardTotalTransaction);
        addTransactionCard.setOnClickListener(view -> {
            Intent send = new Intent(HomeActivity.this, TransactionActivity.class);
            startActivity(send);
        });


        //Make textview clickable and link it to next View Transaction Activity
        transactionViewLink = (TextView) findViewById(R.id.viewIncomeExpensesLinkPage);
        transactionViewLink.setOnClickListener(view -> {
            Intent reportView = new Intent(HomeActivity.this, ViewTransactionActivity.class);
            startActivity(reportView);
        });

        //Make cardview clickable and link it to next View Transaction Activity
        viewIncomeExpensesCard = (CardView) findViewById(R.id.cardViewIncomeExpenses);
        viewIncomeExpensesCard.setOnClickListener(view -> {
            Intent reportView = new Intent(HomeActivity.this, ViewTransactionActivity.class);
            startActivity(reportView);
        });

        //Make imageview clickable and link it BudgetKita icon so it will go to next User Profile Activity
        profileLink = (ImageView) findViewById(R.id.userProfilePictureHome);
        profileLink.setOnClickListener(view -> {
            Intent profile = new Intent(HomeActivity.this, UserProfile.class);
            startActivity(profile);
        });

        //Make imageview clickable and link it logout icon so it will go to next User Profile Activity
        logout = (ImageView) findViewById(R.id.ivLogout);
        logout.setOnClickListener(view -> {
            FirebaseAuth.getInstance().signOut();
            Intent logout = new Intent(HomeActivity.this, MainActivity.class);
            startActivity(logout);
            finish();
        });
    }
}