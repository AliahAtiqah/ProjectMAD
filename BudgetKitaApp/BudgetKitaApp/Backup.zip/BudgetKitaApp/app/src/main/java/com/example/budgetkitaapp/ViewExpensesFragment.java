package com.example.budgetkitaapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.checkerframework.checker.units.qual.A;

import java.util.ArrayList;

public class ViewExpensesFragment extends Fragment {

    RecyclerView rv2;
    ArrayList<Expenses> expensesArrayList;
    ExpensesAdapter expensesAdapter;
    private FirebaseAuth mAuth;
    DatabaseReference databaseReference;

    public ViewExpensesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_view_expenses, container, false);
        rv2 = v.findViewById(R.id.recycler2);

        //Firebase authentication to identify user
        mAuth = FirebaseAuth.getInstance();
        //only the login user can see their data information
        databaseReference = FirebaseDatabase.getInstance().getReference("Expenses").child(mAuth.getCurrentUser().getUid()).child("Expenses");

        expensesArrayList = new ArrayList<>();
        rv2.setHasFixedSize(true);
        rv2.setLayoutManager(new LinearLayoutManager(getActivity()));
        expensesAdapter = new ExpensesAdapter(expensesArrayList, getActivity());
        rv2.setAdapter(expensesAdapter);

        databaseReference.get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                expensesArrayList.clear();

                for(DataSnapshot expensesDatasnap : dataSnapshot.getChildren()){
                    Expenses expenses = expensesDatasnap.getValue(Expenses.class);
                    expenses.setId(expensesDatasnap.getKey());
                    expensesArrayList.add(expenses);
                }
                expensesAdapter.notifyDataSetChanged();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                // if we do not get any data or any error we are displaying
                // a toast message that we do not get any data
                Toast.makeText(getActivity(), "Fail to get the data.", Toast.LENGTH_SHORT).show();
            }
        });

        return v;
    }
}